TRANSFER LOGO PACKAGE
1) transfer-logo-64.png = ready-to-use 64 x 64 pixel logo.
2) transfer-logo.svg = scalable vector version.
For the app, use transfer-logo-64.png or the SVG file.
