// Transfer — public browser settings only.
// Paste your Supabase Project URL and Publishable/anon key below.
// NEVER put the Supabase service_role / secret key in this file.
window.VIP_SUPABASE_CONFIG = {
  url: "PASTE_YOUR_SUPABASE_PROJECT_URL",
  anonKey: "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
