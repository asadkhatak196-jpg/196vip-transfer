-- 196 VIP Transfer: small additive patch for the reviewed schema.
-- Run once in Supabase SQL Editor AFTER the reviewed setup SQL.
-- Does not delete tables or customer data.
begin;

-- Admin-only approval/disable function. It changes the profile role safely
-- because the reviewed schema intentionally does not grant users role updates.
create or replace function public.vip_admin_set_driver_status(
  p_driver_id uuid,
  p_status text
) returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.vip_is_admin() then
    raise exception 'Only an admin can change driver status';
  end if;
  if p_status not in ('approved','disabled','pending') then
    raise exception 'Invalid driver status';
  end if;

  update public.vip_driver_applications
     set status = p_status
   where driver_id = p_driver_id;

  if not found then
    raise exception 'Driver application not found';
  end if;

  update public.vip_profiles
     set role = case when p_status = 'approved' then 'driver' else 'customer' end
   where id = p_driver_id;
end;
$$;
revoke all on function public.vip_admin_set_driver_status(uuid,text) from public;
grant execute on function public.vip_admin_set_driver_status(uuid,text) to authenticated;

-- Drivers can maintain their own vehicle row; the app uses this table
-- to show vehicle model/category/plate to customers (never driver phone).
commit;
